# StarTune 星律 — Android wrapper project

This project wraps the existing single-page StarTune HTML prototype in an Android WebView. It is a starter project, not a prebuilt APK.

## Build locally
- Install JDK 17 and Gradle 8.9.
- From this folder run: `gradle assembleDebug`
- APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Build in the cloud from a phone
1. Create a GitHub repository named `StarTune`.
2. Upload the contents of this project (not the outer ZIP file) to the repository's `main` branch.
3. Open the repository's **Actions** tab and run **Build StarTune APK** (or push to `main`).
4. Open the completed workflow run and download the `StarTune-debug-apk` artifact. Extract it to get `app-debug.apk`.
5. Open the APK on your Android phone and allow installation from the browser/file app if Android asks.

The workflow builds a debug APK for personal testing. It is not a Play Store release package. The prototype's demo entries are sample metadata; playback works for audio files selected from the device. Online music catalogues require licensed APIs and are not included.
